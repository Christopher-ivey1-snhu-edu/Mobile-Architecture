package com.example.firstandroidappcii;

import android.app.Activity;

public class LoginScreen extends Activity {
}
